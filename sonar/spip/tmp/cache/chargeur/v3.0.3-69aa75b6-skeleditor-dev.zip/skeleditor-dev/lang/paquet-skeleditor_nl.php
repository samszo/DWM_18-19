<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-skeleditor?lang_cible=nl
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'skeleditor_description' => 'Bewerken van skeletten, CSS, js, in het privé gedeelte',
	'skeleditor_slogan' => 'Skeletten bewerken'
);
