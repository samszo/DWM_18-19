<?php
// This is a SPIP language file  --  Ceci est un fichier langue de SPIP
// extrait automatiquement de https://trad.spip.net/tradlang_module/paquet-skeleditor?lang_cible=de
// ** ne pas modifier le fichier **

if (!defined('_ECRIRE_INC_VERSION')) {
	return;
}

$GLOBALS[$GLOBALS['idx_lang']] = array(

	// S
	'skeleditor_description' => 'SPIP-Templates (Skelette) im Redaktionssystem bearbeiten',
	'skeleditor_slogan' => 'Template Editor'
);
